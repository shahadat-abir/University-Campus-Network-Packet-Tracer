UNIVERSITY CAMPUS NETWORK USING CISCO PACKET TRACER
Cisco Packet Tracer campus network design, configuration and testing project
Built and tested in Cisco Packet Tracer 9.0.0 on 29 October 2026.

CONTENTS
  University_Campus_Network_Premier_University.pkt  Native Packet Tracer project (saved with File > Save As by Packet Tracer itself)
  Project_Report.docx / Project_Report.pdf          Final report (25 sections incl. testing and appendix). In Word: right-click Contents > Update Field.
  Project_Proposal.docx                             Pre-implementation proposal (template-based). See report Section 22 for deviations.
  Topology.png                                      As-built design diagram
  IP_Addressing_Plan.csv                            VLSM/IPv6 plan with network, mask, first/last usable, broadcast, gateway, DHCP range
  Testing_Matrix.csv                                31 tests: 23 PASS, 2 FAIL, 6 NOT TESTED (observed results only)
  Device_Configurations/                            Applied CLI scripts for 9 network devices + GUI settings for end devices/servers/IoT
  Screenshots/                                      24 full-resolution screenshots (PNG) from the running simulation, cropped to the window

LAB-ONLY CREDENTIALS (simulation only - change before reuse)
  Network devices: enable secret / user netadmin password = PULab2026 (SSH v2 only, from 10.10.4.64/27, e.g. NMS-PC)
  Wi-Fi PU-STUDENT (WPA2-PSK AES): PUStudent2026
  IoT server http://10.10.4.36 : iotadmin / PUIoT2026

QUICK DEMO
  1. PC-LAB1 > Desktop > Web Browser: portal.pu.internal  (DNS + inter-VLAN + HTTP)
  2. PC-LAB1 > Command Prompt: ping 198.51.100.10 (PAT works) ; ping 10.10.3.201 (blocked by STUDENT-IN)
  3. INTERNET-SRV > Web Browser: 203.0.113.5 (static NAT) ; ping 203.0.113.5 (blocked by EDGE-IN)
  4. PC-LIB1: ping 2001:DB8:ACAD:60::35 (IPv6 over OSPFv3)
  5. Alt+click IOT-MOTION-1 -> IOT-LIGHT-1 turns on (rule on SRV-IOT)

KNOWN ISSUES
  - SLAAC did not assign PC-LIB1 an IPv6 address; a static address is used.
  - R-EDGE console rejected the enable secret when typed remotely; SSH works.
  - The saved file was not reopened and re-tested after the final save.
